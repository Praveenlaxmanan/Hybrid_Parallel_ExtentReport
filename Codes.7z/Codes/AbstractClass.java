package com.framework.libraries;

 abstract class AbstractClass {
	
	
	abstract void test1();
	
	void test(){
		
		System.out.println("developed");
	}
	

}
