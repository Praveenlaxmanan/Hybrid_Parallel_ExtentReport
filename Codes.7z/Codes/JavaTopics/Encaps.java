package JavaTopics;

public class Encaps {
	
	private int balance=888;
	
	public void getbalance(int pin){
		
		if(pin==2345){
			
			System.out.println("Hi your current balance is: "+ balance);
		}
		else{
			System.out.println("Please enter the valid pin");
		}
	}
public void setbalance(int bal){
	
	this.balance=bal;
}
public void withdrawl(int pin, int ammount){
	
	if(pin==2345&&ammount<=balance){
		
		System.out.println("Sucessfully withdrawn money" + ammount);
		setbalance(balance-ammount);
		//this.balance=balance-ammount;
	}
	else{
		System.out.println("you dont haave the sufficient balance");
	}
	
	
}
public static void main(String[] args) {
	Encaps e=  new Encaps();
	e.getbalance(2345);
	e.withdrawl(2345, 500);
	e.getbalance(2345);
	
}


}
