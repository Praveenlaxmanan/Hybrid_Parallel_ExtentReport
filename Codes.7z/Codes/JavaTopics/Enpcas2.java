package JavaTopics;

public class Enpcas2 {

	public static void main(String[] args) {
		Encaps xx = new Encaps();
		xx.getbalance(2345);
		
	}
	
}
