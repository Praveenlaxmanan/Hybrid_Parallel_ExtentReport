package com.framework.libraries;

public class ThisKey {
	
	
	public ThisKey() {
	
		System.out.println("This key, default constructor");
	
	}

}
