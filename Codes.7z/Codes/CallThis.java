package com.framework.libraries;

public class CallThis {

	public void Test1(){
		
       this.Test1();		
	}
	
	
	public static void main(String[] args) {
		
		CallThis x = new CallThis();
		x.Test1();
		
	}
	
}
